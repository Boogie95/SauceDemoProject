package test.ui;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.Header;
import pages.ProductsPage;
import test.data.TestData;

import java.util.ArrayList;
import java.util.List;

public class ProductsSortingTest extends BaseTestWithLogin{
    @Test(dataProviderClass = TestData.class,dataProvider ="testOptionSort")
    public void sortingTest(String option){
     ProductsPage productsPage=new ProductsPage(driver);
     Assert.assertTrue(productsPage.isSorted(option));
    }
}
